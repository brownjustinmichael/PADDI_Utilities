#define JC2D   76

#define JCGRID 10  
#define JCTEMP 11 
#define JCCHEM 12 
#define JCSTREAM 13 
#define JCPSI 14   
#define JCPSIDX 15 
#define JCPSIDY 16


#define JC3D   77
#define JC3R   78

#define JPTEMP 20 
#define JPAX 21  
#define JPAY 22  
#define JPVELX 23
#define JPVELY 24
#define JPVELZ 25
#define JPPRES 26
#define JPGRID 27

